﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello ,Please Enter The Maximum Number of Items in the List ");

string? maximumNumberFromUser;
int maximumNumber;


//TODO:: add validation for the maximumNumber & static Console 
while(true)
{
    maximumNumberFromUser = Console.ReadLine();

    bool isValidNumber = int.TryParse(maximumNumberFromUser, out maximumNumber);

    if ( !isValidNumber || maximumNumber <= 0)
    {
        Console.WriteLine("Invalid input. Please enter a positive number:");
    }
    else
    { break; }
}



maximumNumber = Convert.ToInt32(maximumNumberFromUser);

Console.WriteLine($" The addition up to {maximumNumber} is : ");

int sum =0;
for (int iterator = 1; iterator <= maximumNumber; iterator++)
{
  //Console.WriteLine($" iterator = {iterator} , old sum = {sum} ");
    sum = sum + iterator;

  //Console.WriteLine($" new sum = {sum} ");
   
}
// O(c)
int seriessum = maximumNumber * (maximumNumber + 1) / 2;

Console.WriteLine($" The total sum from 1 to with for method {maximumNumber} = {sum} ");
Console.WriteLine($" The total sum from 1 to with formula method {maximumNumber} = {seriessum} ");