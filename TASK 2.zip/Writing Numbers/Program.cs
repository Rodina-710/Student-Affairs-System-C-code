﻿// See https://aka.ms/new-console-template for more information
using System.Diagnostics;
using System.Text;

Console.WriteLine("Hello ,Please Enter The Maximum Number of Items in the List ");
string? maximumNumberFromUser;

maximumNumberFromUser = Console.ReadLine();
int maximumNumber;

maximumNumber = Convert.ToInt32(maximumNumberFromUser);


string numbers = string.Empty;

Stopwatch stopwatch = Stopwatch.StartNew();

for (int i = 1; i <= maximumNumber; i++)
{
    //numbers = numbers + i.ToString() + ",";
    //String Interpolation :
    // String Data structure is immutable, so each time we concatenate, a new string is created as it is an array of characters.
    numbers = $"{numbers}{i},";

}

// Remove last comma 
if (numbers.EndsWith(","))
{
    numbers = numbers.Remove(numbers.Length - 1, 1);
}

stopwatch.Stop();

//Time Complexity of the code is O(n^2)

Console.WriteLine($"Old approach Elapsed Seconds = {stopwatch.Elapsed.TotalSeconds}");
Console.WriteLine(numbers);


stopwatch.Start();

//StringBulider is not peremetive so it locate in the heap memory and must be initialized before use 
StringBuilder numbersNewapproach = new StringBuilder();

for (int i = 1; i <= maximumNumber; i++)
{
    //String Builder is mutable , so it allows for efficient string concatenation without creating new strings each time as it is a list Data structure.
    numbersNewapproach.Append($"{i},");

}

// Remove last comma
if (numbersNewapproach.Length>0 && numbersNewapproach[numbersNewapproach.Length-1] == ',')
{
    numbersNewapproach.Length--;

}

stopwatch.Stop();

//Time Complexity of the code is O(n)


Console.WriteLine(numbersNewapproach);
Console.WriteLine($"New approach Elapsed Seconds = {stopwatch.Elapsed.TotalSeconds}");
